De acordo com as instruções estabelecidas no Guião Número 8,

	o projeto do Quartus Prime segue em duas fases:

		Fase 1 = "Implemente a máquina de acordo com as especificações descritas acima 
sem o modulo display Decode" (fonte: Guião 8)

		Fase 2 = Versão Final do Projeto com tudo implementado.